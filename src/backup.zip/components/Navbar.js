import {ArrowRightIcon } from "@heroicons/react/solid";
import React from "react";
import './Navbar.css';

export default function Navbar(){
    return(
        <header className="header">
            <div className="navContainer">
                <a className="navLink">
                    <a href="#about" className="me">
                    About Me
                    </a>
                </a>
                <nav className="nav">
                    <a href="#projects" className="navButtons">
                        My Past Work
                    </a>
                    <a href="#skills" className="navButtons">
                        Skills
                    </a>	  
                </nav>
            </div>
        </header>
    );
}