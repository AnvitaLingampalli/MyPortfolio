import React from "react";
import './About.css';

export default function About(){
    return(
        <section id="about">
            <div className="container">
                <div className="hpb">
                    <h1>Hi, I am Anvita
                    <br/>Welcome to my portfolio!
                    </h1>
                    <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Qui
                    laborum quasi, incidunt dolore iste nostrum cupiditate voluptas?
                    Laborum, voluptas natus?
                    </p>
                    <div className="twoButtons">
                        <a href="#contact" id="contact">
                           Contact Me
                        </a>
                        <a href="#projectB" id="projectB">
                            My projects
                        </a>
                    </div>
                </div>
                <div className="image">
                    <img className="image1" alt="animated picture" src="./myPic.jpg"/>
                    
                </div>
            </div>

        </section>
    )
}